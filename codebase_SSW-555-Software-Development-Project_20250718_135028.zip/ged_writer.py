#Jamie Rollins
#M2_B3 GEDCOM Writer
#I pledge my honor that I have abided by the Stevens Honor System.

from gedcom.element.individual import IndividualElement
from gedcom.element.family import FamilyElement
from gedcom.element.element import Element
from gedcom.parser import Parser
from datetime import datetime, date
import re
import os

class GedWriter:
    def __init__(self, gedcom_file_path):
        """
        Initialize the GEDCOM writer with a file path
        
        Args:
            gedcom_file_path (str): Path to the GEDCOM file to modify
        """
        self.gedcom_file_path = gedcom_file_path
        self.parser = Parser()
        self.parser.parse_file(gedcom_file_path)
        self.root = self.parser.get_root_element()
        
        # Track existing IDs to avoid conflicts
        self.existing_individual_ids = set()
        self.existing_family_ids = set()
        self._load_existing_ids()
        
        # Month abbreviations for date formatting
        self.month_abbr = {
            1: "JAN", 2: "FEB", 3: "MAR", 4: "APR", 5: "MAY", 6: "JUN",
            7: "JUL", 8: "AUG", 9: "SEP", 10: "OCT", 11: "NOV", 12: "DEC"
        }
        
        # Store individual and family data for validation
        self.individuals_data = {}
        self.families_data = {}
        self._load_data()
    
    def _load_existing_ids(self):
        """Load all existing individual and family IDs from the GEDCOM file"""
        for element in self.parser.get_root_child_elements():
            if element.get_tag() == "INDI":
                indi_id = self._extract_id_from_element(element)
                self.existing_individual_ids.add(indi_id)
            elif element.get_tag() == "FAM":
                fam_id = self._extract_id_from_element(element)
                self.existing_family_ids.add(fam_id)
    
    def _load_data(self):
        """Load individual and family data for validation purposes"""
        for element in self.parser.get_root_child_elements():
            if element.get_tag() == "INDI":
                indi_id = self._extract_id_from_element(element)
                self.individuals_data[indi_id] = self._extract_individual_data(element)
            elif element.get_tag() == "FAM":
                fam_id = self._extract_id_from_element(element)
                self.families_data[fam_id] = self._extract_family_data(element)
    
    def _extract_id_from_element(self, element):
        """Extract ID from a GEDCOM element"""
        element_str = str(element)
        # Extract ID from format like "0 @I1@ INDI" or "0 @F1@ FAM"
        match = re.search(r'@([^@]+)@', element_str)
        return match.group(1) if match else None
    
    def _extract_individual_data(self, element):
        """Extract individual data for validation"""
        data = {
            'name': 'NA',
            'gender': 'NA',
            'birth_date': None,
            'death_date': None,
            'families_as_child': [],
            'families_as_spouse': []
        }
        
        for child in element.get_child_elements():
            if child.get_tag() == "NAME":
                name = str(child)[2:].replace(str(child.get_tag()), '').strip()
                data['name'] = name.splitlines()[0] if name else 'NA'
            elif child.get_tag() == "SEX":
                gender = str(child)[2:].replace(str(child.get_tag()), '').strip()
                data['gender'] = gender.splitlines()[0] if gender else 'NA'
            elif child.get_tag() == "BIRT":
                for date_elem in child.get_child_elements():
                    if date_elem.get_tag() == "DATE":
                        date_str = str(date_elem)[2:].replace(str(date_elem.get_tag()), '').strip()
                        data['birth_date'] = self._parse_gedcom_date(date_str)
            elif child.get_tag() == "DEAT":
                for date_elem in child.get_child_elements():
                    if date_elem.get_tag() == "DATE":
                        date_str = str(date_elem)[2:].replace(str(date_elem.get_tag()), '').strip()
                        data['death_date'] = self._parse_gedcom_date(date_str)
            elif child.get_tag() == "FAMC":
                fam_id = str(child)[2:].replace(str(child.get_tag()), '').strip()
                fam_id = re.search(r'@([^@]+)@', fam_id)
                if fam_id:
                    data['families_as_child'].append(fam_id.group(1))
            elif child.get_tag() == "FAMS":
                fam_id = str(child)[2:].replace(str(child.get_tag()), '').strip()
                fam_id = re.search(r'@([^@]+)@', fam_id)
                if fam_id:
                    data['families_as_spouse'].append(fam_id.group(1))
        
        return data
    
    def _extract_family_data(self, element):
        """Extract family data for validation"""
        data = {
            'husband_id': None,
            'wife_id': None,
            'children': [],
            'marriage_date': None,
            'divorce_date': None
        }
        
        for child in element.get_child_elements():
            if child.get_tag() == "HUSB":
                husb_id = str(child)[2:].replace(str(child.get_tag()), '').strip()
                husb_id = re.search(r'@([^@]+)@', husb_id)
                if husb_id:
                    data['husband_id'] = husb_id.group(1)
            elif child.get_tag() == "WIFE":
                wife_id = str(child)[2:].replace(str(child.get_tag()), '').strip()
                wife_id = re.search(r'@([^@]+)@', wife_id)
                if wife_id:
                    data['wife_id'] = wife_id.group(1)
            elif child.get_tag() == "CHIL":
                chil_id = str(child)[2:].replace(str(child.get_tag()), '').strip()
                chil_id = re.search(r'@([^@]+)@', chil_id)
                if chil_id:
                    data['children'].append(chil_id.group(1))
            elif child.get_tag() == "MARR":
                for date_elem in child.get_child_elements():
                    if date_elem.get_tag() == "DATE":
                        date_str = str(date_elem)[2:].replace(str(date_elem.get_tag()), '').strip()
                        data['marriage_date'] = self._parse_gedcom_date(date_str)
            elif child.get_tag() == "DIV":
                for date_elem in child.get_child_elements():
                    if date_elem.get_tag() == "DATE":
                        date_str = str(date_elem)[2:].replace(str(date_elem.get_tag()), '').strip()
                        data['divorce_date'] = self._parse_gedcom_date(date_str)
        
        return data
    
    def _parse_gedcom_date(self, date_str):
        """Parse GEDCOM date format to datetime object"""
        if not date_str or date_str == 'NA':
            return None
        
        try:
            # Handle formats like "10 JAN 2002", "JAN 2002", "2002"
            parts = date_str.strip().split()
            
            if len(parts) == 3:  # "10 JAN 2002"
                day, month, year = int(parts[0]), parts[1], int(parts[2])
            elif len(parts) == 2:  # "JAN 2002"
                day, month, year = 1, parts[0], int(parts[1])
            elif len(parts) == 1:  # "2002"
                day, month, year = 1, "JAN", int(parts[0])
            else:
                return None
            
            # Convert month abbreviation to number
            month_num = list(self.month_abbr.values()).index(month.upper()) + 1
            
            return date(year, month_num, day)
        except (ValueError, IndexError):
            return None
    
    def _format_gedcom_date(self, date_obj):
        """Format datetime object to GEDCOM date format"""
        if not date_obj:
            return None
        
        if isinstance(date_obj, datetime):
            date_obj = date_obj.date()
        
        day = date_obj.day
        month = self.month_abbr[date_obj.month]
        year = date_obj.year
        
        return f"{day} {month} {year}"
    
    def _generate_next_id(self, prefix):
        """Generate the next available ID for individuals or families"""
        existing_ids = self.existing_individual_ids if prefix == "I" else self.existing_family_ids
        
        # Find the highest number
        max_num = 0
        for existing_id in existing_ids:
            if existing_id.startswith(prefix):
                try:
                    num = int(existing_id[1:])
                    max_num = max(max_num, num)
                except ValueError:
                    continue
        
        return f"{prefix}{max_num + 1}"
    
    def _validate_birth_date(self, birth_date, parent_ids):
        """Validate that birth date is reasonable given parent information"""
        if not birth_date or not parent_ids:
            return True
        
        # Check if child is born before parents
        for parent_id in parent_ids:
            if parent_id in self.individuals_data:
                parent_data = self.individuals_data[parent_id]
                if parent_data['birth_date'] and birth_date < parent_data['birth_date']:
                    return False
        
        # Check if child is born too far in the future (more than 1 year from now)
        current_date = date.today()
        if birth_date > current_date.replace(year=current_date.year + 1):
            return False
        
        return True
    
    def _validate_marriage_date(self, marriage_date, spouse_ids):
        """Validate that marriage date is reasonable given spouse information"""
        if not marriage_date or not spouse_ids:
            return True
        
        # Check if marriage is before both spouses were born
        for spouse_id in spouse_ids:
            if spouse_id in self.individuals_data:
                spouse_data = self.individuals_data[spouse_id]
                if spouse_data['birth_date'] and marriage_date < spouse_data['birth_date']:
                    return False
        
        # Check if marriage is too far in the future
        current_date = date.today()
        if marriage_date > current_date.replace(year=current_date.year + 1):
            return False
        
        return True
    
    def add_individual(self, name, gender, birth_date=None, death_date=None, family_as_child=None):
        """
        Add a new individual to the GEDCOM file
        
        Args:
            name (str): Full name of the individual
            gender (str): Gender ('M' or 'F')
            birth_date (datetime.date, optional): Birth date
            death_date (datetime.date, optional): Death date
            family_as_child (str, optional): Family ID where this person is a child
            
        Returns:
            str: The ID of the newly created individual
            
        Raises:
            ValueError: If validation fails
        """
        # Validate inputs
        if not name or not gender:
            raise ValueError("Name and gender are required")
        
        if gender not in ['M', 'F']:
            raise ValueError("Gender must be 'M' or 'F'")
        
        # Validate birth date
        if birth_date and not self._validate_birth_date(birth_date, [family_as_child] if family_as_child else []):
            raise ValueError("Birth date is invalid (child born before parent or too far in future)")
        
        # Validate death date
        if death_date and birth_date and death_date < birth_date:
            raise ValueError("Death date cannot be before birth date")
        
        # Validate family_as_child exists
        if family_as_child and family_as_child not in self.existing_family_ids:
            raise ValueError(f"Family {family_as_child} does not exist")
        
        # Generate new individual ID
        new_id = self._generate_next_id("I")
        self.existing_individual_ids.add(new_id)
        
        # Create individual element
        individual = IndividualElement(self.root, new_id)
        
        # Add name
        name_elem = Element(self.root, "NAME", name)
        individual.add_child_element(name_elem)
        
        # Add gender
        gender_elem = Element(self.root, "SEX", gender)
        individual.add_child_element(gender_elem)
        
        # Add birth date
        if birth_date:
            birth_elem = Element(self.root, "BIRT")
            birth_date_elem = Element(self.root, "DATE", self._format_gedcom_date(birth_date))
            birth_elem.add_child_element(birth_date_elem)
            individual.add_child_element(birth_elem)
        
        # Add death date
        if death_date:
            death_elem = Element(self.root, "DEAT")
            death_date_elem = Element(self.root, "DATE", self._format_gedcom_date(death_date))
            death_elem.add_child_element(death_date_elem)
            individual.add_child_element(death_elem)
        
        # Add family as child reference
        if family_as_child:
            famc_elem = Element(self.root, "FAMC", f"@{family_as_child}@")
            individual.add_child_element(famc_elem)
            
            # Update family to include this child
            self._add_child_to_family(family_as_child, new_id)
        
        # Add to root
        self.root.add_child_element(individual)
        
        # Update internal data
        self.individuals_data[new_id] = {
            'name': name,
            'gender': gender,
            'birth_date': birth_date,
            'death_date': death_date,
            'families_as_child': [family_as_child] if family_as_child else [],
            'families_as_spouse': []
        }
        
        return new_id
    
    def add_family(self, husband_id=None, wife_id=None, marriage_date=None, divorce_date=None):
        """
        Add a new family to the GEDCOM file
        
        Args:
            husband_id (str, optional): ID of the husband
            wife_id (str, optional): ID of the wife
            marriage_date (datetime.date, optional): Marriage date
            divorce_date (datetime.date, optional): Divorce date
            
        Returns:
            str: The ID of the newly created family
            
        Raises:
            ValueError: If validation fails
        """
        # Validate that at least one spouse is provided
        if not husband_id and not wife_id:
            raise ValueError("At least one spouse must be provided")
        
        # Validate that individuals exist
        if husband_id and husband_id not in self.existing_individual_ids:
            raise ValueError(f"Husband {husband_id} does not exist")
        
        if wife_id and wife_id not in self.existing_individual_ids:
            raise ValueError(f"Wife {wife_id} does not exist")
        
        # Validate marriage date
        spouse_ids = [id for id in [husband_id, wife_id] if id]
        if marriage_date and not self._validate_marriage_date(marriage_date, spouse_ids):
            raise ValueError("Marriage date is invalid (before spouse birth or too far in future)")
        
        # Validate divorce date
        if divorce_date and marriage_date and divorce_date < marriage_date:
            raise ValueError("Divorce date cannot be before marriage date")
        
        # Generate new family ID
        new_id = self._generate_next_id("F")
        self.existing_family_ids.add(new_id)
        
        # Create family element
        family = FamilyElement(self.root, new_id)
        
        # Add husband
        if husband_id:
            husb_elem = Element(self.root, "HUSB", f"@{husband_id}@")
            family.add_child_element(husb_elem)
            
            # Update individual to include this family as spouse
            self._add_spouse_to_individual(husband_id, new_id)
        
        # Add wife
        if wife_id:
            wife_elem = Element(self.root, "WIFE", f"@{wife_id}@")
            family.add_child_element(wife_elem)
            
            # Update individual to include this family as spouse
            self._add_spouse_to_individual(wife_id, new_id)
        
        # Add marriage date
        if marriage_date:
            marr_elem = Element(self.root, "MARR")
            marr_date_elem = Element(self.root, "DATE", self._format_gedcom_date(marriage_date))
            marr_elem.add_child_element(marr_date_elem)
            family.add_child_element(marr_elem)
        
        # Add divorce date
        if divorce_date:
            div_elem = Element(self.root, "DIV")
            div_date_elem = Element(self.root, "DATE", self._format_gedcom_date(divorce_date))
            div_elem.add_child_element(div_date_elem)
            family.add_child_element(div_elem)
        
        # Add to root
        self.root.add_child_element(family)
        
        # Update internal data
        self.families_data[new_id] = {
            'husband_id': husband_id,
            'wife_id': wife_id,
            'children': [],
            'marriage_date': marriage_date,
            'divorce_date': divorce_date
        }
        
        return new_id
    
    def add_child_to_family(self, family_id, child_id):
        """
        Add an existing child to an existing family
        
        Args:
            family_id (str): ID of the family
            child_id (str): ID of the child
            
        Raises:
            ValueError: If validation fails
        """
        if family_id not in self.existing_family_ids:
            raise ValueError(f"Family {family_id} does not exist")
        
        if child_id not in self.existing_individual_ids:
            raise ValueError(f"Child {child_id} does not exist")
        
        # Validate that child is not already in this family
        if child_id in self.families_data[family_id]['children']:
            raise ValueError(f"Child {child_id} is already in family {family_id}")
        
        # Validate birth date
        child_data = self.individuals_data[child_id]
        family_data = self.families_data[family_id]
        
        if child_data['birth_date']:
            parent_ids = [family_data['husband_id'], family_data['wife_id']]
            parent_ids = [pid for pid in parent_ids if pid]
            
            if not self._validate_birth_date(child_data['birth_date'], parent_ids):
                raise ValueError("Child birth date is invalid (born before parent)")
        
        # Add child to family
        self._add_child_to_family(family_id, child_id)
        
        # Update child's family reference
        self._add_family_as_child_to_individual(child_id, family_id)
    
    def _add_child_to_family(self, family_id, child_id):
        """Helper method to add child to family element"""
        # Find the family element
        for element in self.parser.get_root_child_elements():
            if element.get_tag() == "FAM" and self._extract_id_from_element(element) == family_id:
                # Add child element
                chil_elem = Element(self.root, "CHIL", f"@{child_id}@")
                element.add_child_element(chil_elem)
                
                # Update internal data
                if family_id in self.families_data:
                    self.families_data[family_id]['children'].append(child_id)
                break
    
    def _add_spouse_to_individual(self, individual_id, family_id):
        """Helper method to add family as spouse to individual"""
        # Find the individual element
        for element in self.parser.get_root_child_elements():
            if element.get_tag() == "INDI" and self._extract_id_from_element(element) == individual_id:
                # Add family as spouse element
                fams_elem = Element(self.root, "FAMS", f"@{family_id}@")
                element.add_child_element(fams_elem)
                
                # Update internal data
                if individual_id in self.individuals_data:
                    self.individuals_data[individual_id]['families_as_spouse'].append(family_id)
                break
    
    def _add_family_as_child_to_individual(self, individual_id, family_id):
        """Helper method to add family as child to individual"""
        # Find the individual element
        for element in self.parser.get_root_child_elements():
            if element.get_tag() == "INDI" and self._extract_id_from_element(element) == individual_id:
                # Add family as child element
                famc_elem = Element(self.root, "FAMC", f"@{family_id}@")
                element.add_child_element(famc_elem)
                
                # Update internal data
                if individual_id in self.individuals_data:
                    self.individuals_data[individual_id]['families_as_child'].append(family_id)
                break
    
    def save_file(self, output_path=None):
        """
        Save the modified GEDCOM file
        
        Args:
            output_path (str, optional): Path to save the file. If None, overwrites original file
        """
        if output_path is None:
            output_path = self.gedcom_file_path
        
        # Convert the GEDCOM structure back to file format
        with open(output_path, 'w', encoding='utf-8') as f:
            self._write_element(f, self.root, 0)
    
    def _write_element(self, file, element, level):
        """Recursively write GEDCOM elements to file"""
        # Write the main element
        tag = element.get_tag()
        value = element.get_value()
        
        if tag == "INDI" or tag == "FAM":
            # For individuals and families, include the ID
            element_id = self._extract_id_from_element(element)
            file.write(f"{level} @{element_id}@ {tag}\n")
        else:
            # For other elements
            if value:
                file.write(f"{level} {tag} {value}\n")
            else:
                file.write(f"{level} {tag}\n")
        
        # Write child elements
        for child in element.get_child_elements():
            self._write_element(file, child, level + 1)
    
    def get_individual_info(self, individual_id):
        """Get information about an individual"""
        if individual_id not in self.individuals_data:
            return None
        return self.individuals_data[individual_id]
    
    def get_family_info(self, family_id):
        """Get information about a family"""
        if family_id not in self.families_data:
            return None
        return self.families_data[family_id]
    
    def list_all_individuals(self):
        """List all individuals in the GEDCOM file"""
        return list(self.individuals_data.keys())
    
    def list_all_families(self):
        """List all families in the GEDCOM file"""
        return list(self.families_data.keys()) 