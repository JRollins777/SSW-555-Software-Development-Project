import unittest
import tempfile
import os
from datetime import date

#import Class I want to test
import ged_parser
import ged_writer


class Test(unittest.TestCase):

    sprint = ged_parser.Sprint1() #instantiates the Sprint1Class

################## USER STORY: List living single ##################

    '''Test that the amount of individuals listed do not exceed the amount of individuals in the gedcom file'''
    def test_0_Singles_Size(self):
        print("Starting to test: Singles_Size",end="\n\n")

        # get actual output from class
        actual = self.sprint.getSingles()

        #get all the individuals in the gedcom file
        indi = self.sprint.individuals_dict

        #check that the list does not exceed the amount of individuals in the gedcom file
        self.assertTrue(len(actual) <= len(indi))
        print("Number of total individuals: " + str(len(indi)))
        print("Number of singles: " + str(len(actual)), end="\n\n")        

        print("Finished testing: Singles_Size",end="\n\n")


    '''Test that the amount of individuals listed is not less than 0'''
    def test_1_Singles_Size2(self):
        print("Starting to test: Singles_Size2",end="\n\n")

        # get actual output from class
        actual = self.sprint.getSingles()

        #get all the individuals in the gedcom file
        indi = self.sprint.individuals_dict

        #check that the list does not exceed the amount of individuals in the gedcom file
        self.assertTrue(len(actual) >= 0)
        print("Number of singles: " + str(len(actual)), end="\n\n")
        
        print("Finished testing: Singles_Size2",end="\n\n")


    '''Test that all individuals listed are single'''
    #TODO
    def test_2_Singles(self):
        print("Starting to test: Singles",end="\n\n")

        # Get actual output from class
        actual = self.sprint.getSinglesElem()

        # iterate through each element in the list
        for i in actual:
            # and assert that each one returns false
            self.assertFalse(self.sprint.isMarr(i))

        # An indiviudal counts as single if they do not have the tag 'FAMS'
        

        print("Finished testing: Singles",end="\n\n")


    '''Test that all individuals listed are living'''
    #TODO
    def test_3_Singles_Alive(self):
        print("Starting to test: Singles_Alive",end="\n\n")
        
        # Get the return list of individuals listed
        actual = self.sprint.getSinglesElem()

        # iterate through each element in the list
        for i in actual:
            # and assert that each one returns False when checking if they are dead
            self.assertFalse(self.sprint.isDead(i))
        print("Finished testing: Singles_Alive",end="\n\n")


    '''Test that all individuals listed match the expected output'''
    #TODO
    def test_4_Singles_Value(self):
        print("Starting to test: Singles_Value",end="\n\n")

        # get actual output from class
        actual = self.sprint.getSingles()

        # expected output
        expected = ['I1', 'I4', 'I8', 'I13', 'I15']

        #check that the actual matched the expected output
        self.assertEqual(actual, expected)
        print("Expected: " + str(expected))
        print("Actual: " + str(actual),end="\n\n")


################### USER STORY: List multiple births ##################

    # Test that the amount of siblings who have the same birthday do not exceed the amount of individuals in the gedcom file
    def test_0_Multiples_Size(self):
        print("Starting to test: Multiples_Size",end="\n\n")

        # get actual output from class
        actual = self.sprint.getMultipleBirths()

        # get all the individuals in the gedcom file
        indi = self.sprint.individuals_dict

        self.assertTrue(len(actual) <= len(indi))
        print("Number of total individuals: " + str(len(indi)))
        print("Number of multiple births: " + str(len(actual)), end="\n\n") 

        print("Finished testing: Multiples_Size",end="\n\n")

# Test that the amount of siblings who have the same birthday is not less than 0
    def test_1_Multiples_Size2(self):
        print("Starting to test: Multiples_Size2",end="\n\n")

        # get actual output from class
        actual = self.sprint.getMultipleBirths()

        # get all the individuals in the gedcom file
        indi = self.sprint.individuals_dict

        self.assertTrue(len(actual) >= 0)
        print("Number of singles: " + str(len(actual)), end="\n\n")

        print("Finished testing: Multiples_Size2",end="\n\n")


# Test that all siblings in a group have the same birthday
    def test_2_Multiples_Birthday(self):
        print("Starting to test: Multiples_Birthday",end="\n\n")

        # get actual output from class
        actual = self.sprint.getMultipleBirthsElem()

        # iterate through each sibling group
        for sg in actual[:-1]:
            # check that the surrent individual has the same birthday as the next individual
            for i in sg:
                self.assertEqual(self.sprint.getBirthDate(i), self.sprint.getBirthDate(sg[i+1]))

        print("Finished testing: Multiples_Birthday",end="\n\n")

# Test that all individuals in the list are actually siblings
    def test_3_Multiples_Siblings(self):
        print("Starting to test: Multiples_Siblings",end="\n\n")

        # get output from class
        actual = self.sprint.getMultipleBirthsElem()

        # iterate through each sibling group
        for sg in actual[:-1]:
            # iterate through each sibling in the group
            for i in sg:
                # and assert that each one is a sibling of the next individual by seeing they are both children of the same family
                self.assertEqual(self.sprint.getChildFamily(i), self.sprint.getChildFamily(sg[i+1]))
                
        print("Finished testing: Multiples_Siblings",end="\n\n")


    # Test that all siblings who have the same birthday are listed in a list of lists
    def test_4_Multiples(self):
        print("Starting to test: Multiples",end="\n\n")

        # Get the actual output from the class
        actual = self.sprint.getMultipleBirths()

        # Expected output from class
        expected = [['I1', 'I4']]

        # Assert that actual matches expected output
        self.assertEqual(actual, expected)
        print("Expected: " + str(expected))
        print("Actual: " + str(actual), end="\n\n")

        print("Finished testing: Multiples",end="\n\n")


################### USER STORY: GEDCOM Writer Tests ##################

class TestGedWriter(unittest.TestCase):
    
    def setUp(self):
        """Set up test fixtures before each test method"""
        # Create a temporary copy of the test file for each test
        self.temp_file = tempfile.NamedTemporaryFile(mode='w', suffix='.ged', delete=False)
        with open('TEST_FILE.ged', 'r') as original:
            self.temp_file.write(original.read())
        self.temp_file.close()
        
        # Initialize the writer with the temporary file
        self.writer = ged_writer.GedWriter(self.temp_file.name)
    
    def tearDown(self):
        """Clean up after each test method"""
        # Remove the temporary file
        if os.path.exists(self.temp_file.name):
            os.unlink(self.temp_file.name)
    
    def test_0_writer_initialization(self):
        """Test that the GEDCOM writer initializes correctly"""
        print("Starting to test: writer_initialization", end="\n\n")
        
        # Check that existing IDs are loaded
        self.assertIsInstance(self.writer.existing_individual_ids, set)
        self.assertIsInstance(self.writer.existing_family_ids, set)
        self.assertGreater(len(self.writer.existing_individual_ids), 0)
        self.assertGreater(len(self.writer.existing_family_ids), 0)
        
        # Check that data is loaded
        self.assertIsInstance(self.writer.individuals_data, dict)
        self.assertIsInstance(self.writer.families_data, dict)
        
        print("Finished testing: writer_initialization", end="\n\n")
    
    def test_1_add_individual_basic(self):
        """Test adding a basic individual with minimal information"""
        print("Starting to test: add_individual_basic", end="\n\n")
        
        # Add a new individual
        new_id = self.writer.add_individual("John Doe", "M")
        
        # Verify the individual was added
        self.assertIsInstance(new_id, str)
        self.assertTrue(new_id.startswith("I"))
        self.assertIn(new_id, self.writer.existing_individual_ids)
        
        # Verify individual data
        individual_info = self.writer.get_individual_info(new_id)
        self.assertIsNotNone(individual_info)
        self.assertEqual(individual_info['name'], "John Doe")
        self.assertEqual(individual_info['gender'], "M")
        
        print("Finished testing: add_individual_basic", end="\n\n")
    
    def test_2_add_individual_with_dates(self):
        """Test adding an individual with birth and death dates"""
        print("Starting to test: add_individual_with_dates", end="\n\n")
        
        birth_date = date(1990, 5, 15)
        death_date = date(2020, 3, 10)
        
        new_id = self.writer.add_individual("Jane Smith", "F", birth_date, death_date)
        
        # Verify the individual was added
        individual_info = self.writer.get_individual_info(new_id)
        self.assertEqual(individual_info['birth_date'], birth_date)
        self.assertEqual(individual_info['death_date'], death_date)
        
        print("Finished testing: add_individual_with_dates", end="\n\n")
    
    def test_3_add_individual_validation_errors(self):
        """Test validation errors when adding individuals"""
        print("Starting to test: add_individual_validation_errors", end="\n\n")
        
        # Test missing name
        with self.assertRaises(ValueError):
            self.writer.add_individual("", "M")
        
        # Test missing gender
        with self.assertRaises(ValueError):
            self.writer.add_individual("John Doe", "")
        
        # Test invalid gender
        with self.assertRaises(ValueError):
            self.writer.add_individual("John Doe", "X")
        
        # Test death before birth
        birth_date = date(1990, 5, 15)
        death_date = date(1980, 3, 10)
        with self.assertRaises(ValueError):
            self.writer.add_individual("John Doe", "M", birth_date, death_date)
        
        # Test non-existent family
        with self.assertRaises(ValueError):
            self.writer.add_individual("John Doe", "M", family_as_child="F999")
        
        print("Finished testing: add_individual_validation_errors", end="\n\n")
    
    def test_4_add_family_basic(self):
        """Test adding a basic family"""
        print("Starting to test: add_family_basic", end="\n\n")
        
        # First add two individuals
        husband_id = self.writer.add_individual("Husband Name", "M")
        wife_id = self.writer.add_individual("Wife Name", "F")
        
        # Add a family
        family_id = self.writer.add_family(husband_id, wife_id)
        
        # Verify the family was added
        self.assertIsInstance(family_id, str)
        self.assertTrue(family_id.startswith("F"))
        self.assertIn(family_id, self.writer.existing_family_ids)
        
        # Verify family data
        family_info = self.writer.get_family_info(family_id)
        self.assertIsNotNone(family_info)
        self.assertEqual(family_info['husband_id'], husband_id)
        self.assertEqual(family_info['wife_id'], wife_id)
        
        print("Finished testing: add_family_basic", end="\n\n")
    
    def test_5_add_family_with_dates(self):
        """Test adding a family with marriage and divorce dates"""
        print("Starting to test: add_family_with_dates", end="\n\n")
        
        # Add individuals
        husband_id = self.writer.add_individual("Husband Name", "M", date(1980, 1, 1))
        wife_id = self.writer.add_individual("Wife Name", "F", date(1982, 1, 1))
        
        marriage_date = date(2005, 6, 15)
        divorce_date = date(2015, 12, 20)
        
        family_id = self.writer.add_family(husband_id, wife_id, marriage_date, divorce_date)
        
        # Verify family data
        family_info = self.writer.get_family_info(family_id)
        self.assertEqual(family_info['marriage_date'], marriage_date)
        self.assertEqual(family_info['divorce_date'], divorce_date)
        
        print("Finished testing: add_family_with_dates", end="\n\n")
    
    def test_6_add_family_validation_errors(self):
        """Test validation errors when adding families"""
        print("Starting to test: add_family_validation_errors", end="\n\n")
        
        # Test no spouses provided
        with self.assertRaises(ValueError):
            self.writer.add_family()
        
        # Test non-existent husband
        with self.assertRaises(ValueError):
            self.writer.add_family(husband_id="I999")
        
        # Test non-existent wife
        wife_id = self.writer.add_individual("Wife Name", "F")
        with self.assertRaises(ValueError):
            self.writer.add_family(wife_id=wife_id, husband_id="I999")
        
        # Test divorce before marriage
        husband_id = self.writer.add_individual("Husband Name", "M")
        marriage_date = date(2005, 6, 15)
        divorce_date = date(2000, 12, 20)
        with self.assertRaises(ValueError):
            self.writer.add_family(husband_id, wife_id, marriage_date, divorce_date)
        
        print("Finished testing: add_family_validation_errors", end="\n\n")
    
    def test_7_add_child_to_family(self):
        """Test adding an existing child to an existing family"""
        print("Starting to test: add_child_to_family", end="\n\n")
        
        # Create a family
        husband_id = self.writer.add_individual("Husband Name", "M", date(1980, 1, 1))
        wife_id = self.writer.add_individual("Wife Name", "F", date(1982, 1, 1))
        family_id = self.writer.add_family(husband_id, wife_id, date(2005, 6, 15))
        
        # Create a child
        child_id = self.writer.add_individual("Child Name", "M", date(2010, 3, 20))
        
        # Add child to family
        self.writer.add_child_to_family(family_id, child_id)
        
        # Verify child was added to family
        family_info = self.writer.get_family_info(family_id)
        self.assertIn(child_id, family_info['children'])
        
        # Verify child has family reference
        child_info = self.writer.get_individual_info(child_id)
        self.assertIn(family_id, child_info['families_as_child'])
        
        print("Finished testing: add_child_to_family", end="\n\n")
    
    def test_8_add_child_validation_errors(self):
        """Test validation errors when adding children to families"""
        print("Starting to test: add_child_validation_errors", end="\n\n")
        
        # Test non-existent family
        child_id = self.writer.add_individual("Child Name", "M")
        with self.assertRaises(ValueError):
            self.writer.add_child_to_family("F999", child_id)
        
        # Test non-existent child
        family_id = self.writer.add_family()
        with self.assertRaises(ValueError):
            self.writer.add_child_to_family(family_id, "I999")
        
        # Test adding same child twice
        child_id = self.writer.add_individual("Child Name", "M")
        family_id = self.writer.add_family()
        self.writer.add_child_to_family(family_id, child_id)
        with self.assertRaises(ValueError):
            self.writer.add_child_to_family(family_id, child_id)
        
        print("Finished testing: add_child_validation_errors", end="\n\n")
    
    def test_9_birth_date_validation(self):
        """Test birth date validation logic"""
        print("Starting to test: birth_date_validation", end="\n\n")
        
        # Create parents
        parent1_id = self.writer.add_individual("Parent 1", "M", date(1980, 1, 1))
        parent2_id = self.writer.add_individual("Parent 2", "F", date(1982, 1, 1))
        family_id = self.writer.add_family(parent1_id, parent2_id, date(2005, 6, 15))
        
        # Test child born before parents (should fail)
        child_birth_before_parent = date(1975, 1, 1)
        with self.assertRaises(ValueError):
            self.writer.add_individual("Child", "M", child_birth_before_parent, family_as_child=family_id)
        
        # Test child born after parents (should succeed)
        child_birth_after_parent = date(2010, 1, 1)
        child_id = self.writer.add_individual("Child", "M", child_birth_after_parent, family_as_child=family_id)
        self.assertIsNotNone(child_id)
        
        print("Finished testing: birth_date_validation", end="\n\n")
    
    def test_10_marriage_date_validation(self):
        """Test marriage date validation logic"""
        print("Starting to test: marriage_date_validation", end="\n\n")
        
        # Create individuals
        person1_id = self.writer.add_individual("Person 1", "M", date(1980, 1, 1))
        person2_id = self.writer.add_individual("Person 2", "F", date(1982, 1, 1))
        
        # Test marriage before birth (should fail)
        marriage_before_birth = date(1975, 1, 1)
        with self.assertRaises(ValueError):
            self.writer.add_family(person1_id, person2_id, marriage_before_birth)
        
        # Test marriage after birth (should succeed)
        marriage_after_birth = date(2005, 6, 15)
        family_id = self.writer.add_family(person1_id, person2_id, marriage_after_birth)
        self.assertIsNotNone(family_id)
        
        print("Finished testing: marriage_date_validation", end="\n\n")
    
    def test_11_save_and_load_file(self):
        """Test that the file can be saved and loaded correctly"""
        print("Starting to test: save_and_load_file", end="\n\n")
        
        # Add some new data
        new_individual_id = self.writer.add_individual("Test Person", "M", date(1990, 5, 15))
        new_family_id = self.writer.add_family()
        
        # Save the file
        self.writer.save_file()
        
        # Load the file again with a new writer instance
        new_writer = ged_writer.GedWriter(self.temp_file.name)
        
        # Verify the data is still there
        self.assertIn(new_individual_id, new_writer.existing_individual_ids)
        self.assertIn(new_family_id, new_writer.existing_family_ids)
        
        individual_info = new_writer.get_individual_info(new_individual_id)
        self.assertEqual(individual_info['name'], "Test Person")
        
        print("Finished testing: save_and_load_file", end="\n\n")
    
    def test_12_id_generation(self):
        """Test that IDs are generated correctly and don't conflict"""
        print("Starting to test: id_generation", end="\n\n")
        
        # Add multiple individuals and families
        individual_ids = []
        family_ids = []
        
        for i in range(5):
            indi_id = self.writer.add_individual(f"Person {i}", "M")
            individual_ids.append(indi_id)
            
            fam_id = self.writer.add_family()
            family_ids.append(fam_id)
        
        # Verify all IDs are unique
        self.assertEqual(len(set(individual_ids)), 5)
        self.assertEqual(len(set(family_ids)), 5)
        
        # Verify IDs follow the correct format
        for indi_id in individual_ids:
            self.assertTrue(indi_id.startswith("I"))
            self.assertTrue(indi_id[1:].isdigit())
        
        for fam_id in family_ids:
            self.assertTrue(fam_id.startswith("F"))
            self.assertTrue(fam_id[1:].isdigit())
        
        print("Finished testing: id_generation", end="\n\n")
    
    def test_13_complex_family_scenario(self):
        """Test a complex family scenario with multiple relationships"""
        print("Starting to test: complex_family_scenario", end="\n\n")
        
        # Create grandparents
        grandfather_id = self.writer.add_individual("Grandfather", "M", date(1950, 1, 1))
        grandmother_id = self.writer.add_individual("Grandmother", "F", date(1952, 1, 1))
        grandparent_family_id = self.writer.add_family(grandfather_id, grandmother_id, date(1970, 6, 15))
        
        # Create parents
        father_id = self.writer.add_individual("Father", "M", date(1975, 3, 20), family_as_child=grandparent_family_id)
        mother_id = self.writer.add_individual("Mother", "F", date(1977, 7, 10))
        parent_family_id = self.writer.add_family(father_id, mother_id, date(2000, 9, 5))
        
        # Create children
        child1_id = self.writer.add_individual("Child 1", "M", date(2005, 4, 15), family_as_child=parent_family_id)
        child2_id = self.writer.add_individual("Child 2", "F", date(2008, 11, 22), family_as_child=parent_family_id)
        
        # Verify all relationships
        grandparent_family = self.writer.get_family_info(grandparent_family_id)
        parent_family = self.writer.get_family_info(parent_family_id)
        
        self.assertIn(father_id, grandparent_family['children'])
        self.assertIn(child1_id, parent_family['children'])
        self.assertIn(child2_id, parent_family['children'])
        
        # Verify individual family references
        father_info = self.writer.get_individual_info(father_id)
        self.assertIn(grandparent_family_id, father_info['families_as_child'])
        self.assertIn(parent_family_id, father_info['families_as_spouse'])
        
        print("Finished testing: complex_family_scenario", end="\n\n")


if __name__ == '__main__':
    # begin the unittest.main()
    unittest.main()
